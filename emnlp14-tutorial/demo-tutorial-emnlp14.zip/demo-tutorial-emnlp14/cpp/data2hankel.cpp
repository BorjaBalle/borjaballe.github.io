#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

#include "mex.h"

bool sort_func(pair<string,unsigned long long int> p1, pair<string,unsigned long long int> p2) { return (p1.second > p2.second); }
bool rev_sort_func(pair<string,unsigned long long int> p1, pair<string,unsigned long long int> p2) { return (p1.second < p2.second); }

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
	// Inputs: name of data file (as string), maximum Hankel size (as integer, OPTIONAL)

	// Check for proper number of input and output arguments
	if (nrhs < 1) {
		mexErrMsgTxt("(data2hankel) One input argument required at least\n");
		return;
	}

	// Check to be sure input type
	if (!mxIsChar(prhs[0])){
		mexErrMsgTxt("(data2hankel) First input must be of type string\n");
		return;
	}

	char * tmpstr = mxArrayToString(prhs[0]);
	string strfname(tmpstr);
	mxFree(tmpstr);

	// If present, second input must be scalar
	int Nmax = 0;
	if (nrhs > 1) {
		int mrows = mxGetM(prhs[1]);
		int ncols = mxGetN(prhs[1]);
		if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mrows==1 && ncols==1) ) {
			mexErrMsgTxt("(data2hankel) Second input must be a noncomplex scalar\n");
			return;
		}
		Nmax = mxGetPr(prhs[1])[0];
	}

	// Open data file and check for errors
	ifstream strfile(strfname.c_str());
	if (strfile.fail()) {
		mexPrintf("(data2hankel) Error opening file '%s'\n", strfname.c_str());
		mexErrMsgTxt("(data2hankel) Aborting...\n");
		return;
	}

	mexPrintf("==== Running MEX 'data2hankel' ====\n");
	mexPrintf("++ Reading data from file '%s'... ", strfname.c_str());

	// Read sample size and alphabet info
	string x;
	getline(strfile,x);
	istringstream datainfo(x);
	int Nin;
	int Ain;
	datainfo >> Nin >> Ain;

	// Read the strings in the sample, save string counts into dictionary
	unsigned long long int N = 0;
	unsigned long long int L = 0;
	map<string,unsigned long long int> C;
	while (!strfile.eof()) {
		getline(strfile,x);
		strfile >> ws;
		istringstream xs(x);
		string z;
		int xlength;
		int symbol;
		// Read length
		xs >> xlength >> ws;
		// Read the symbols, convert into string
		// XXX This only works if the alphabet is small enough XXX
		while (!xs.eof()) {
			xs >> symbol >> ws;
			z.push_back('a' + (char)symbol);
		}
		// Add a +1 count to the dictionary for string z
		C[z] += 1;
		// Save information to compute average length
		L += z.length();
		// Update the number of read strings
		N++;
	}

	mexPrintf("Done!\n");
	mexPrintf("++ Sample size: %d\n", N);
	mexPrintf("++ Number of unique strings: %d\n", C.size());
	mexPrintf("++ Alphabet size: %d\n", Ain);
	mexPrintf("++ Average string length: %f\n", (float) L / (float) N);

	// Find prefixes and suffixes in the sample (and compute their weights)
	// XXX We only look for prefixes in the first half of the string XXX
	// XXX We only look for suffixes in the second half of the string XXX
	mexPrintf("++ Looking up all prefixes and suffixes... ");

	map<string,unsigned long long int> Cp;
	map<string,unsigned long long int> Cs;
	map<string,unsigned long long int>::iterator it = C.begin();
	
	while (it != C.end()) {
		string z = it->first;
		unsigned long long int cnt = it->second;
		int L = z.length();
		int max_pL = (L/2) + 1;
		int max_sL = (L/2) + 1;
		if (L < 2) {
			max_pL = L;
			max_sL = L;
		}
		// Consider all possible prefixes, add the counts
		for (int i = 0; i <= max_pL; i++) {
			Cp[z.substr(0,i)] += cnt;
		}
		// Consider all possible suffixes, add the counts
		for (int i = 0; i <= max_sL; i++) {
			Cs[z.substr(L-i,i)] += cnt;
		}
		// Be ready for next string
		it++;
	}

	mexPrintf("Done!\n");
	mexPrintf("++ Total num. of prefixes: %d\n", Cp.size());
	mexPrintf("++ Total num. of suffixes: %d\n", Cs.size());

	// Create index for prefixes and suffixes to row/column indices (two versions)
	mexPrintf("++ Creating prefix/suffix -> row/column index... ");

	map<string,unsigned long long int> Ip;
	map<string,unsigned long long int> Is;
	// If the size of the Hankel is unlimited, will take all prefs and suffs
	// NOTE: The indices will agree with the sorting of prefixes and suffixes inside the Ip and Is maps
	if (Nmax == 0) {
		int idx = 1;
		for (it = Cp.begin(); it != Cp.end(); it++) {
			Ip[it->first] = idx;
			idx++;
		}
		idx = 1;
		for (it = Cs.begin(); it != Cs.end(); it++) {
			Is[it->first] = idx;
			idx++;
		}
	}
	// If the size of the Hankel is limited, will take the 'Nmax' most frequent prefs and suffs
	// NOTE: The indices will *not* agree with the sorting of prefixes and suffixes inside the Ip and Is maps
	int Nprefs = Cp.size();
	int Nsufs = Cs.size();
	if (Nmax > 0) {
		vector<pair<string,unsigned long long int> > counts;
		// Sort prefixes by counts
		for (it = Cp.begin(); it != Cp.end(); it++) counts.push_back(*it);
		sort(counts.begin(),counts.end(),sort_func);
		// And take Nmax most frequent prefixes
		if (Nprefs > Nmax) Nprefs = Nmax;
		for (int idx = 0; idx < Nprefs; idx++) Ip[counts[idx].first] = idx + 1;
		// Sort suffixes by counts
		counts.clear();
		for (it = Cs.begin(); it != Cs.end(); it++) counts.push_back(*it);
		sort(counts.begin(),counts.end(),sort_func);
		// And take Nmax most frequent suffixes
		if (Nsufs > Nmax) Nsufs = Nmax;
		for (int idx = 0; idx < Nsufs; idx++) Is[counts[idx].first] = idx + 1;
	}

	mexPrintf("Done!\n");
	if (Nmax > 0) {
		mexPrintf("++ Hankel size was limited by user to: %d x %d\n", Nprefs, Nsufs);
	}

	// Write the Hankel matrices to disk (in sparse form)
	// XXX The files will then be loaded from Matlab. This makes debugging easier. XXX
	mexPrintf("++ Writing Hankel matrices to disk... ");

	mexPrintf("H ");
	ofstream hankelfile;
	hankelfile.open("H.dat", ios_base::out | ios_base::trunc );
	it = C.begin();
	while (it != C.end()) {
		string s = it->first;
		unsigned long long int cnt = it->second;
		int L = s.length();
		for (int i = 0; i <= L; i++) {
			// If the prefix and suffix are in the dictionary
			// Add the corresponding entry to the Hankel matrix
			if (Ip.count(s.substr(0,i)) > 0 && Is.count(s.substr(i,L)) > 0) {
				hankelfile << Ip[s.substr(0,i)] << " " << Is[s.substr(i,L)] << " " << cnt << endl;
			}
		}
		// Be ready for next string
		it++;
	}
	hankelfile.close();
	// Write the translated Hankel matrices to disk (in sparse form)
	for (char c = 'a'; c < 'a' + (char) Ain; c++) {
		mexPrintf("H%c ",c);
		hankelfile.open((string("H") + string(1,c) + string(".dat")).c_str(), ios_base::out | ios_base::trunc );
		it = C.begin();
		while (it != C.end()) {
			string s = it->first;
			unsigned long long int cnt = it->second;
			int L = s.length();
			for (int i = 0; i < L; i++) {
				if (s[i] == c && Ip.count(s.substr(0,i)) > 0 && Is.count(s.substr(i+1,L)) > 0) {
				       	hankelfile << Ip[s.substr(0,i)] << " " << Is[s.substr(i+1,L)] << " " << cnt << endl;
				}
			}
			// Be ready for next string
			it++;
		}
		hankelfile.close();
	}
	// Write the counts of suffixes (in sparse form)
	mexPrintf("hp ");
	hankelfile.open("hp.dat", ios_base::out | ios_base::trunc );
	it = C.begin();
	while (it != C.end()) {
		string s = it->first;
		unsigned long long int cnt = it->second;
		if (Is.count(s) > 0) {
			hankelfile << Is[s] << " 1 " << cnt << endl;
		}
		// Be ready for next string
		it++;
	}
	hankelfile.close();
	// Write the counts of prefixes (in sparse form)
	mexPrintf("hs");
	hankelfile.open("hs.dat", ios_base::out | ios_base::trunc );
	it = C.begin();
	while (it != C.end()) {
		string s = it->first;
		unsigned long long int cnt = it->second;
		if (Ip.count(s) > 0) {
			hankelfile << Ip[s] << " 1 " << cnt << endl;
		}
		// Be ready for next string
		it++;
	}
	hankelfile.close();
	mexPrintf("\tDone!\n");

	// Write to disk the prefixes and suffixes indexing the Hankel matrices
	mexPrintf("++ Writing prefixes and suffixes to disk... ");

	ofstream stringsfile;
	stringsfile.open("prefs.dat", ios_base::out | ios_base::trunc );
	// Use different code depending on whether size of Hankel was limited or not
	if (Nmax == 0) {
		for (it = Ip.begin(); it != Ip.end(); it++) {
			stringsfile << it->first << endl;
		}
	} else {
		vector<pair<string,unsigned long long int> > pref2idx;
		// Sort prefixes by index 
		for (it = Ip.begin(); it != Ip.end(); it++) pref2idx.push_back(*it);
		sort(pref2idx.begin(),pref2idx.end(),rev_sort_func);
		// And save them in this order
		if (Nprefs > Nmax) Nprefs = Nmax;
		for (int idx = 0; idx < Nprefs; idx++) stringsfile << pref2idx[idx].first << endl;
	}
	stringsfile.close();
	stringsfile.open("suffs.dat", ios_base::out | ios_base::trunc );
	// Use different code depending on whether size of Hankel was limited or not
	if (Nmax == 0) {
		for (it = Is.begin(); it != Is.end(); it++) {
			stringsfile << it->first << endl;
		}
	} else {
		vector<pair<string,unsigned long long int> > suff2idx;
		// Sort prefixes by index 
		for (it = Is.begin(); it != Is.end(); it++) suff2idx.push_back(*it);
		sort(suff2idx.begin(),suff2idx.end(),rev_sort_func);
		// And save them in this order
		if (Nprefs > Nmax) Nprefs = Nmax;
		for (int idx = 0; idx < Nprefs; idx++) stringsfile << suff2idx[idx].first << endl;
	}
	stringsfile.close();

	mexPrintf("Done!\n");

	// Write to disk training size and alphabet
	mexPrintf("++ Writing task information... ");

        ofstream taskfile("taskinfo.dat");
	taskfile << N << " ";
        for (char c = 'a'; c < 'a' + (char) Ain; c++) taskfile << c;
        taskfile.close();

	mexPrintf("Done!\n");

	mexPrintf("==== End of MEX 'data2hankel' ====\n");

	return;
}

