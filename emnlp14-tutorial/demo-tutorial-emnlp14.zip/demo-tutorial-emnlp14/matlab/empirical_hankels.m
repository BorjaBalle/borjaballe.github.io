% Parses a training file in Pautomac format
% And returns the corresponding empirical Hankel matrices
% Can use 'maxN' to limit the size of the Hankel matrix
function [hkl] = empirical_hankels(trainfile,maxN)

	% Parse training file into sparse Hankels for matlab
	if (nargin > 1)
		data2hankel(trainfile,maxN);
	else
		data2hankel(trainfile);
	end;

	% Load information about the training set
	[N,alphabet] = textread('taskinfo.dat','%d %s');
	alphabet = alphabet{1};

	% Create a data struture to hold all the Hankels
	hkl = struct();
	hkl.type = 'empirical_hankel';
	hkl.sample_size = N;
	hkl.alphabet = alphabet;

	% Load hankel matrices and vectors into data structure
	H = load('H.dat');
	hkl.H = spconvert(H);
	clear('H');
	for i = 1:length(alphabet)
		a = alphabet(i);
		Ha = load(['H' a '.dat']);
		hkl.(a) = spconvert(Ha);
		clear('Ha');
	end;
	hp = load('hp.dat');
	hkl.hp = spconvert(hp);
	clear('hp');
	hs = load('hs.dat');
	hkl.hs = spconvert(hs);
	clear('hs');

	% Load prefixes and suffixes indexing the Hankels
        fid = fopen('prefs.dat');
        data = textscan(fid,'%s','delimiter','\n');
        fclose(fid);
        hkl.ps = data{1};
        fid = fopen('suffs.dat');
        data = textscan(fid,'%s','delimiter','\n');
        fclose(fid);
        hkl.ss = data{1};

	% Fix dimensions (due to the use of sparse matrices)
	pdim = length(hkl.ps);
	sdim = length(hkl.ss);
	if (size(hkl.H,1) ~= pdim || size(hkl.H,2) ~= sdim)
		hkl.H(pdim,sdim) = 0;
	end;
	for i = 1:length(alphabet)
		a = alphabet(i);
		if (size(hkl.(a),1) ~= pdim || size(hkl.(a),2) ~= sdim)
			hkl.(a)(pdim,sdim) = 0;
		end;
	end;
	if (size(hkl.hp,1) ~= sdim)
		hkl.hp(sdim,1) = 0;
	end;
	if (size(hkl.hs,1) ~= pdim)
		hkl.hs(pdim,1) = 0;
	end;

	% Normalize the probabilities
	hkl.H = hkl.H / N;
	hkl.hp = hkl.hp / N;
	hkl.hs = hkl.hs / N;
	for i = 1:length(alphabet)
		a = alphabet(i);
		hkl.(a) = hkl.(a) / N;
	end;

