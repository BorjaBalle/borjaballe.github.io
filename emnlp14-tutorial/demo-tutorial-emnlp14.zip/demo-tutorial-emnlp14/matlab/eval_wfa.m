% Evaluate a WFA on a string
function w = eval_wfa(wa,s)
	% Use stepwise normalization to correct numeric errors
	gotzero = false;
	C = 0;
	w = wa.a0;
	for i = 1:length(s)
		w = w*wa.(s(i));
		c = norm(w);
		if (c > 0)
			w = w / c;
			C = C + log(c);
		else
			gotzero = true;
		end;
	end;
	w = w*wa.ainf;
	if (~gotzero)
		w = exp(C + log(w)) ;
	end;

