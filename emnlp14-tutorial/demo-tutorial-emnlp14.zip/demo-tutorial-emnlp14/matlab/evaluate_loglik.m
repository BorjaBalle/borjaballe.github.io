% Evaluate the likelihood of a test set on several WFA
function [lls] = evaluate_loglik(was,test_file)
	
	% Load test set
	test_set = load_pautomac_data(test_file,was{1}.alphabet);

	% Evaluate each WFA
	lls = [];
	for i = 1:length(was)
		wa = was{i};
		ll = 0;
		for j = 1:length(test_set)
			s = test_set{j};
			% Compute probability of s under wa (beware negative numbers!)
			pr_s = eval_wfa(wa,s);
			% Update the log-likelihood of the test set
			ll = ll + log(abs(pr_s));
		end;
		lls = [lls ll];
	end;

