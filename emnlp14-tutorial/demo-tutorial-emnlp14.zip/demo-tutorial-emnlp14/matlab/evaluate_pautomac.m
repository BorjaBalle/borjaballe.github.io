% Takes an array of WFA and evaluates each of them on a validation set
% Validation follows Pautomac format where strings and scores are splitted into
% two files
% Returns perplexity scores computed according to Pautomac scoring
% (see http://ai.cs.umbc.edu/icgi2012/challenge/Pautomac/)
function [pplxs] = evaluate_pautomac(was,val_file,val_score_file)
	
	% Load validation set
	val_set = load_pautomac_data(val_file,was{1}.alphabet);
	% Load scores by true model
	fid = fopen(val_score_file);
	true_scores = textscan(fid,'%f','delimiter','\n');
	fclose(fid);
	true_scores = true_scores{1};
	true_scores = true_scores(2:end);

	% Evaluate each WFA
	pplxs = [];
	for i = 1:length(was)
		wa = was{i};
		% Compute scores by our model
		scores = [];
		for i = 1:length(val_set)
			s = val_set{i};
			scores = [scores eval_wfa(wa,s)];
		end;
		% Normalize scores
		scores = abs(scores);
		scores = scores / sum(scores);

		% Compute Pautomac perplexity between scores
		pplx = 0;
		for i = 1:length(true_scores)
			% Check for zero probabilities
			if (scores(i) > 0)
				pplx = pplx + true_scores(i)*log(scores(i))/log(2);
			end;
		end;
		pplx = 2^(-pplx);

		% Save results
		pplxs = [pplxs pplx];
	end;
	
