% Evaluate WER of several WFA on a test data set
function [wers] = evaluate_wer(was,test_file)
	
	% Load test set
	test_set = load_pautomac_data(test_file,was{1}.alphabet);

	% Evaluate each WFA
	wers = [];
	for i = 1:length(was)
		wa = was{i};
		L = 0;
		wer = 0;
		for j = 1:length(test_set)
			s = test_set{j};
			% Compute number of wrongly predicted symbols
			errs = length(s) - sum(predict_wfa(wa,s) == s);
			wer = wer + errs;
			% Update the number of symbols in the test set
			L = L + length(s);
		end;
		% Compute rate per symbol
		wer = wer / L;
		% Save result to array
		wers = [wers wer];
	end;

