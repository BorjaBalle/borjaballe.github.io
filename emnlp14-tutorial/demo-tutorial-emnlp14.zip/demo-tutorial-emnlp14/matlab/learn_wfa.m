% Learn WFA from Hankel matrices
% 'ns' can contain several number of states to try
function [was] = learn_wfa(hkl,ns)

	% Can learn multiple WFA of different sizes with a single SVD computation
	nmax = max(ns);
	% Compute the biggest required SVD of Hankel matrix
	[U,S,V] = svds(hkl.H,nmax);
	
	was = {};

	for i = 1:length(ns)
		n = ns(i);
		% Truncate SVD
		Us = U(:,1:n);
		Ss = S(1:n,1:n);
		Vs = V(:,1:n);
		% Compute projections
		projU = inv(sqrt(Ss)) * Us';
		projV = Vs * inv(sqrt(Ss));
		% Initialize WFA data structure
		wa = struct();
		wa.type = 'wfa';
		wa.alphabet = hkl.alphabet;
		wa.nstates = n;
		% Compute SVD from Hankels
		wa.a0 = hkl.hp' * projV;
		wa.ainf = projU * hkl.hs;
		A = zeros(n,n);
		for i = 1:length(wa.alphabet)
			a = wa.alphabet(i);
			wa.(a) = projU * hkl.(a) * projV;
			A = A + wa.(a);
		end;
		% XXX Normalize to add up to 1 XXX
		%Z = wa.a0*inv(eye(n) - A)*wa.ainf;
		%wa.ainf = wa.ainf / Z;
		% Add WFA to the result
		was = [was wa];
	end;


