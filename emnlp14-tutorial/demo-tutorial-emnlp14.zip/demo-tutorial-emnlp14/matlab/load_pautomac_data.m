% Load a data set of string in Pautomac format
function [S] = load_pautomac_data(test_file,A)
	% Open file and discard first line
	fid = fopen(test_file);
	[str,c] = fgets(fid);
	% Parse strings and save to S
	S = {};
	[str,c] = fgets(fid);
	while (c > 0)
		str_parse = textscan(str,'%d');
		str_parse = str_parse{1};
		% Discard first symbol (the length of the string)
		s = '';
		for i = 2:length(str_parse)
			s = [s A(str_parse(i) + 1)];
		end;
		S{end+1} = s;
		% Get next string
		[str,c] = fgets(fid);
	end;
	fclose(fid);

