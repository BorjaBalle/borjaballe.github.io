% Predict most likely next symbols for each prefix in 's' from a WFA
function [pr] = predict_wfa(wa,s)
	A = wa.alphabet();
	terminals = struct();
	for i = 1:length(A)
		a = A(i);
		terminals.(a) = wa.(a) * wa.ainf;
	end;
	pr = '';
	w = wa.a0;
	for i = 1:length(s)
		pred = A(1);
		max_p = w*terminals.(pred);
		for j = 2:length(A)
			a = A(j);
			pred_p = w*terminals.(a);	
			if (pred_p > max_p)
				max_p = pred_p;
				pred = a;
			end;
		end;
		pr = [pr pred];
		w = w*wa.(s(i));
	end;

