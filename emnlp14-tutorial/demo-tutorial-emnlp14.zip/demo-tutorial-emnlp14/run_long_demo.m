% Demo of spectral learning algorithm for WFA
% This code is provided as an example for the tutorial on "Spectral Learning
% Techniques for Weighted Automata, Transducers, and Grammars" given at
% EMNLP-2014 by B. Balle, A. Quattoni and X. Carreras
% http://www.lsi.upc.edu/~bballe/emnlp14-tutorial/

% Clean environment and terminal
clear;
clc;

% Add our routines to the Matlab path
currpath = pwd;
addpath([currpath '/matlab'],[currpath '/cpp']);

% Compile C++ code if needed
if (exist('data2hankel') ~= 3)
	fprintf('== The MEX compiler in your Matlab needs to be configured for compiling C++ code ==\n');
	fprintf('== Please choose the right option in the following setup menu ==\n');
	fprintf('\n\nPress any key to continue...\n');
	pause;
	mex -setup;
	cd cpp;
	mex 'data2hankel.cpp';
	cd ..;
end;

% Start verboseness
echo on;

% This is a demo of a spectral algorithm for learning Weighted Finite Automata (WFA)
% (e.g. see [Balle, Carreras, Luque, and Quattoni 2014] for details about the algorithm)
%
% The dataset used in this demo was extracted from the task number 8 in the Pautomac Competition
% (see http://ai.cs.umbc.edu/icgi2012/challenge/Pautomac/)
%
% The steps involved in the demo are the following:
% 1) Parse the training set and estimate empirical Hankel matrices
% 2) Learn several WFA with different numbers of states
% 3) Evaluate the hypotheses on a test set
% 4) Refine the search interval for the number of states and learn new WFA
% 5) Choose the best hypothesis according to the test set
% 6) Evaluate the resulting model on the validation set
%
% Press any key to start...
pause;

% Parse data in training file (calls C++ code for speed)
% If the dataset is too big, you always have the option of limiting the size of the Hankel matrices
%max_hankel_size = 1000;
%hkl = empirical_hankels('data/train.dat',max_hankel_size);
hkl = empirical_hankels('data/train.dat');

% Variable 'hkl' contains information from training set formatted for spectral learning
hkl
% We can look at a little subblock from the Hankel matrix 'hkl.H'
full(hkl.H(1:8,1:8))
% Which contains empirical probabilities for strings obtained by concatenating the prefixes:
hkl.ps(1:8)
% And the suffixes:
hkl.ss(1:8)

% Choose number of states for coarse search
ns = [20:10:100];
% Learn multiple WFA with these numbers of states
was = learn_wfa(hkl,ns);

% A WFA is a data structure containing initial and final weights, and transition matrices:
was{1}

% Evaluate all hypotheses on test set in terms of word error rate (WER)
% Note: this process may take a while if the dataset is large
wers = evaluate_wer(was,'data/test.dat');
[best_wer,idx] = min(wers);
best_n = ns(idx(1));

% Refine the search interval for the number of states
ns = [best_n-10:best_n+10];
was = learn_wfa(hkl,ns);
wers = evaluate_wer(was,'data/test.dat');

% Find best model
[best_wer,idx] = min(wers);
best_n = ns(idx(1));
best_wa = was{idx(1)};

% Evaluate on validation set
pplx = evaluate_pautomac({best_wa},'data/validation.dat','data/validation_scores.dat');

% Compare results to true model and best entry in Pautomac competition
%
% Number of states true model: 49
% Number of states of our model:
best_n
%
% Score on validation from true model: 81.375
% Score on validation from best Pautomac entry: 81.403
% Score on validation from our model:
pplx

% Turn off verboseness
echo off;

