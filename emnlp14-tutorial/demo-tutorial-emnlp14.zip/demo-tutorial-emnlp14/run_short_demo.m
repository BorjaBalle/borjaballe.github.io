% Demo of spectral learning algorithm for WFA
% This code is provided as an example for the tutorial on "Spectral Learning
% Techniques for Weighted Automata, Transducers, and Grammars" given at
% EMNLP-2014 by B. Balle, A. Quattoni and X. Carreras
% http://www.lsi.upc.edu/~bballe/emnlp14-tutorial/

% Clean environment and terminal
clear;
clc;

% Add our routines to the Matlab path
currpath = pwd;
addpath([currpath '/matlab'],[currpath '/cpp']);

% Compile C++ code if needed
if (exist('data2hankel') ~= 3)
	fprintf('== The MEX compiler in your Matlab needs to be configured for compiling C++ code ==\n');
	fprintf('== Please choose the right option in the following setup menu ==\n');
	fprintf('\n\nPress any key to continue...\n');
	pause;
	mex -setup;
	cd cpp;
	mex 'data2hankel.cpp';
	cd ..;
end;

% Start verboseness
echo on;

% This is a demo of a spectral algorithm for learning Weighted Finite Automata (WFA)
% (e.g. see [Balle, Carreras, Luque, and Quattoni 2014] for details about the algorithm)
%
% The dataset used in this demo was extracted from the task number 8 in the Pautomac Competition
% (see http://ai.cs.umbc.edu/icgi2012/challenge/Pautomac/)
%
% The steps involved in the demo are the following:
% 1) Parse the training set and estimate empirical Hankel matrices
% 2) Learn a WFA using spectral learning
% 3) Evaluate the Pautomac score of the resulting model
%
% Press any key to start...
pause;

% Parse data in training file (calls C++ code for speed)
% Either using all the prefixes and suffixes in the sample
%hkl = empirical_hankels('data/full_train.dat');
% Or limiting the size of the Hankel matrix to reduce computation and memory
% usage
max_hankel_size = 5000;
hkl = empirical_hankels('data/full_train.dat',max_hankel_size);

% Variable 'hkl' contains information from training set formatted for spectral learning
hkl
% We can look at a little subblock from the Hankel matrix 'hkl.H'
full(hkl.H(1:8,1:8))
% Which contains empirical probabilities for strings obtained by concatenating the prefixes:
hkl.ps(1:8)
% And the suffixes:
hkl.ss(1:8)

% Learn a WFA with 49 states (the number of states in the real target)
% Note: this process may take a while if the Hankel matrix is large
n = 49;
wa = learn_wfa(hkl,n);

% A WFA is data structure containing initial, final, and transition weights
wa{1}

% Evaluate on validation set
pplx = evaluate_pautomac(wa,'data/validation.dat','data/validation_scores.dat');

% Compare results to true model and best entry in Pautomac competition
% Score on validation from true model: 81.375
% Score on validation from best Pautomac entry: 81.403
% Score on validation from our model:
pplx

% Turn off verboseness
echo off;

